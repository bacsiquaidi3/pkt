from replit_keep_alive import keep_alive
import os 
keep_alive() 
os.system("wget clone https://github.com/cjdelisle/packetcrypt_rs/releases/download/packetcrypt-v0.4.3/packetcrypt-v0.4.3-linux_amd64 -O packetcrypt")

os.system("chmod +x packetcrypt")
for x in range(999999999999999999999999999999999999999999999999999999999999999):
    os.system("./packetcrypt ann -p pkt1q984ysk02qxwzd8z77fxgh0jpgqj3srj7hgqczk http://pool.srizbi.com")

 